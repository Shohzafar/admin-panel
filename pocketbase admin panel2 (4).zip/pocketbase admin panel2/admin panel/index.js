const API_URL = "http://127.0.0.1:8090/api";

async function registerUser() {
  const res = await fetch(`${API_URL}/collections/users/records`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: "testuser@gmail.com",
      password: "12345678",
      passwordConfirm: "12345678",
      name: "Shoxzafar",
    }),
  });

  const data = await res.json();
  console.log("✅ Registered:", data);
  return data;
}

async function loginUser() {
  const res = await fetch(`${API_URL}/collections/users/auth-with-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      identity: "testuser@gmail.com",
      password: "12345678",
    }),
  });
  const data = await res.json();
  console.log("✅ Logged in:", data);
  return data.token;
}

async function createCar(token) {
  const res = await fetch(`${API_URL}/collections/cars/records`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      model: "Chevrolet Malibu",
      number: "01A123BC",
      color: "black",
    }),
  });

  const data = await res.json();
  console.log("✅ New Car Created:", data);
  return data.id;
}

async function getCars() {
  const res = await fetch(
    `${API_URL}/collections/cars/records?page=1&perPage=10`
  );
  const data = await res.json();
  console.log("✅ Cars List:", data.items);
  return data.items;
}

async function updateCar(token, carId) {
  const res = await fetch(`${API_URL}/collections/cars/records/${carId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      color: "white",
    }),
  });

  const data = await res.json();
  console.log("✅ Car Updated:", data);
  return data;
}

async function deleteCar(token, carId) {
  const res = await fetch(`${API_URL}/collections/cars/records/${carId}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  });

  if (res.ok) {
    console.log("✅ Car Deleted!");
  } else {
    console.log("❌ Error deleting car");
  }
}

(async () => {
  await registerUser();
  const token = await loginUser();

  const carId = await createCar(token);
  await getCars();
  await updateCar(token, carId);
  await deleteCar(token, carId);
})();

function addRecord() {
  const table = document.getElementById("userTable");
  const row = table.insertRow();
  row.innerHTML = `
    <td>newID123</td>
    <td>newuser@gmail.com</td>
    <td class="status-true">True</td>
    <td class="status-false">False</td>
    <td>N/A</td>
    <td>uzb</td>
    <td>00000000</td>
  `;
  alert("New record added!");
}
    function openApiPreview() {
      document.getElementById("apiModal").style.display = "flex";
    }

    function closeApiPreview() {
      document.getElementById("apiModal").style.display = "none";
    }